This is a Matlab implementation of SIFT algorithm. The parameters and procedure are almost the same as Rob Hess's [opensift](https://github.com/robwhess/opensift) except for the match step.

An article about sw-sift is [here](http://www.sun11.me/blog/2016/sift-implementation-in-matlab/)(in Chinese).

# License

The SIFT algorithm is patented in the United States and cannot be used in commercial products without a license from the University of British Columbia.  For more information, refer to the file LICENSE.
