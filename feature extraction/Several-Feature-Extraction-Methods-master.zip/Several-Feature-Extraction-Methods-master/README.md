# Several-Feature-Extraction-Methods
Several simple feature extraction methods are PCA, LDA, SVD and LLE   
Principal Component Analysis--PCA    
Linear Discriminant Analysis--LDA    
Singular Value Decomposition--SVD    
Locally Linear Embedding--LLE    
main Script：PCAFE.m, LDAFE.m, SVDFE.m, LLEFE.m

# Copyright Clarify
Copyright ownership belongs to Xuesen Yang, shall not be reproduced , copied, or used in other ways without permission. Otherwise Xuesen Yang will have the right to pursue legal responsibilities.
# Editing information
Editor:Xuesen Yang        
Institution: Shenzhen University       
E-mail:1348825332@qq.com       
Edit date:2018-12-20
